from setuptools import setup, find_packages
setup(name='mcav-kan',
    version='0.1',
    description='sca scav mca mcav',
    author='Kan',
    author_email='kanyuanzhi@gmail.com',
    license='MIT license',
    packages=find_packages(),
    platforms = 'any',
    install_requires = [],
)
